package MyModule;

use strict;
use warnings;

use vars qw($var);

$var = "Bar";

sub function
{
    print "In MyModule.\n";
}

1;
